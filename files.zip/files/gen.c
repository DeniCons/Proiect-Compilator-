#include <stdarg.h>   
#include <stdio.h>     
#include <stdlib.h>    

#include "lexer.h"     
#include "ad.h"        
#include "gen.h"      

Text tBegin;   //include-uri, declarații globale
Text tMain;    // codul pentru main
Text tFunctions; // toate funcțiile definite de utilizator
Text tFnHeader;  // folosit pentru construirea header-ului unei funcții, ex: int max(int x, int y)
Text *crtCode;   // este bufferul în care se scrie codul în acest moment
Text *crtVar;    // este bufferul unde se scriu variabilele

// funcția scrie text formatat într-un buffer Text
void Text_write(Text *text,const char *fmt,...){
	va_list va;	        // declară lista de argumente variabile
	va_start(va,fmt);	// „va” este un iterator al listei de argumente variabile
	
	// vsnprintf apelată cu buffer==NULL, sau număr maxim de caractere==0
	// returnează numărul total de caractere, fără \0, care vor fi scrise
	// dacă există un buffer de dimensiune potrivită
	int n = vsnprintf(NULL, 0, fmt, va); // calculează câte caractere ar fi generate. 
	
	// realocă bufferul dinamic pentru a adăuga noile caractere
	char *p = (char*)realloc(text->buf, (text->n + n + 1) * sizeof(char)); //Se mărește bufferul existent ca să încapă noile caractere.
	
	if(p == NULL){ // daca realloc nu reușește → eroare fatală
		puts("not enough memory");  // afișează mesaj
		exit(EXIT_FAILURE);      // oprește programul
	}
	
	// adaugă noile caractere în buffer-ul dinamic
	va_start(va,fmt);		// resetează iteratorul din lista de variabile cu argumente
	vsnprintf(p + text->n, n + 1, fmt, va); // scrie textul în buffer începând de la poziția curentă
	
	text->buf = p;     // actualizează pointerul la buffer
	text->n += n;      // crește dimensiunea textului generat
	va_end(va);        // încheie prelucrarea argumentelor variabile
}

//Eliberează memoria folosită.
void Text_clear(Text *text){
	free(text->buf);   // eliberează memoria bufferului
	text->buf = NULL;  // setează pointerul ca NULL (siguranță)
	text->n = 0;       // resetăm lungimea la 0
}

//Transformă tipurile interne ale limbajului QUICK în tipuri C.
const char *cType(int type){
	switch(type){              // selectează tipul în funcție de identificatorul intern
		case TYPE_INT: return "int";     // tip intern → tip C
		case TYPE_REAL: return "double"; // real → double
		case TYPE_STR: return "str";     // string → str (probabil definit în quick.h)
		default:
			printf("wrong type: %d\n",type); // afișează eroare dacă tipul nu există
			exit(EXIT_FAILURE);               // oprește execuția
	}
}
