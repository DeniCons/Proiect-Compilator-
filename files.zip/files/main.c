/*
#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#include "lexer.h"
#include "utils.h"
#include "parser.h"
extern int line; 

int main(int argc, char* argv[]){
  
   if(argc < 2){
        return 1;
   }
   char* buffer = loadFile(argv[1]); // incraca fisierul

    tokenize(buffer);// vede ce e in fisier 
    showTokens(); //afiseaza 
    parse();
    
    printf("Program corect sintactic!\n");


    return 0;
}*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "lexer.h"
#include "utils.h"
#include "parser.h"

int main(void){
   
    const char *sourceFile = "test/1.q";

    // încarcă fișierul în memorie
    char *buffer = loadFile(sourceFile);

    // produce tokenii și îi afișează 
    tokenize(buffer);
   // showTokens();

    parse();

    printf("Sintaxa ok!");
    
    //free(buffer);

    return 0;
}

