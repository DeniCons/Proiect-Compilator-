#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "lexer.h"
#include "ad.h"
#include "at.h"
#include "gen.h"
#include "quick.h"


int iTk;               // iteratorul în vectorul de tokeni iTk reține indicele curent din lista de tokeni
Token *consumed;       // ultimul token consumat 

// prototipurile 
bool program();
bool defVar();
bool baseType();
bool defFunc();
bool block();
bool funcParams();
bool funcParam();
bool instr();
bool expr();
bool exprLogic();
bool exprAssign();
bool exprComp();
bool exprAdd();
bool exprMul();
bool exprPrefix();
bool factor();

// identic cu err, dar include linia curentă a tokenului
_Noreturn void tkerr(const char *fmt, ...){ 
    fprintf(stderr,"error in line %d: ", tokens[iTk].line);
    va_list va; 
    va_start(va, fmt);
    vfprintf(stderr, fmt, va); // mesaj cu mai multe argumente 
    va_end(va);
    fprintf(stderr,"\n");
    exit(EXIT_FAILURE);
}

//verifica si avanseza tokeni 
bool consume(int code){ // tokenul curent are codul asteptat
    if(tokens[iTk].code==code){
        consumed = &tokens[iTk++];// creste Itk
        return true;
    }
    return false;
}


// program ::= ( defVar | defFunc | block )* FINISH
bool program(){ //#include "quick"
       crtCode=&tMain; // setează bufferul curent de generare a codului în zona tMain
       crtVar=&tBegin; //setează bufferul unde se vor scrie variabilele în tBegin 
       Text_write(&tBegin,"#include \"quick.h\"\n\n"); // scrie în tBegin linia #include "quick.h"
       Text_write(&tMain,"\nint main(){\n"); // scrie la începutul bufferului tMain declarația funcției main()
    addDomain();
    addPredefinedFns();
    for(;;){ // se incearca o definire de var sau o definire de functie sau un bloc de instructiuni
        int start = iTk; //iTk reține indicele curent din lista de tokeni
       
        if(defVar()) continue;
        iTk = start;
        if(defFunc()) continue;
        iTk = start;
        if(block()) continue;
        iTk = start;
        break;
    }
    if(consume(FINISH)) \
    {  Text_write(&tMain,"return 0;\n}\n");// adaugă în bufferul main() instrucțiunea finală return 0 și închiderea acoladei funcției
       FILE *fis=fopen("1.c","w");// deschide fișierul 1.c pentru scriere (creează sau rescrie fișierul)
        if(!fis){// dacă fișierul nu s-a putut deschide → afișează eroare și oprește programul
          printf("cannot write to file 1.c\n");
          exit(EXIT_FAILURE);
         }
         // scrie în fișier secțiunea tBegin (include-uri + variabile globale) #include "quick"
        fwrite(tBegin.buf,sizeof(char),tBegin.n,fis);

        // scrie în fișier toate funcțiile generate
        fwrite(tFunctions.buf,sizeof(char),tFunctions.n,fis);

        // scrie în fișier codul generat pentru funcția main()
        fwrite(tMain.buf,sizeof(char),tMain.n,fis);
        fclose(fis);// închide fișierul 1.c

         delDomain();
        return true; // se verifica daca exista finish la sf programului
    }
    tkerr("eroare de sintaxa (lipseste 'finish' sau constructie invalida)");
    return false;
 
}
 //definirea variabilei
// defVar ::= VAR ID COLON baseType SEMICOLON
bool defVar(){   // var ID : baseType ;
    int start = iTk;

    if(consume(VAR)){
        // întâi trebuie să consumi ID-ul
        if(consume(ID)){
            const char *name = consumed->text;   // ACUM name = "i"
            Symbol *s = searchInCurrentDomain(name);
            if(s) tkerr("symbol redefinition: %s", name);

            s = addSymbol(name, KIND_VAR);//fel var 
            s->local = (crtFn != NULL);

            if(consume(COLON)){
                if(baseType()){
                    s->type = ret.type;
                    if(consume(SEMICOLON)){
                        
                        Text_write(crtVar,"%s %s;\n",cType(ret.type),name); //declaratie "int i";
                        // generează declarația unei variabile în codul C
                      // cType(ret.type) → tipul C (int, double, str)
                     // name → numele variabilei
                     // scrie în bufferul crtVar: "tip nume;\n"
                        return true;
                    }else tkerr("lipseste ';' dupa definirea variabilei");
                }else tkerr("lipseste tipul dupa ':' în definirea variabilei");
            }else tkerr("lipseste ':' dupa numele variabilei");
        }else tkerr("lipseste numele variabilei dupa 'var'");
    }

    iTk = start;
    return false;
}

//definirea tipului
// baseType ::= TYPE_INT | TYPE_REAL | TYPE_STR
bool baseType(){ //verifică dacă tokenul e unul dintre cele trei tipuri de bază
    if(consume(TYPE_INT)){
        ret.type = TYPE_INT;
        ret.lval = false;
        return true;
    }
    if(consume(TYPE_REAL)){
        ret.type = TYPE_REAL;
        ret.lval = false;
        return true;
    }
    if(consume(TYPE_STR)){
        ret.type = TYPE_STR;
        ret.lval = false;
        return true;
    }
    return false;
}


//definirea functiei
// defFunc ::= FUNCTION ID LPAR funcParams? RPAR COLON baseType defVar* block END
bool defFunc(){  
    int start = iTk; // pozitia curenta din vectorul de tokeni
    if(consume(FUNCTION)){ // verifica cuvant cheie
        if(consume(ID)){  //nume funcție          <<  "int max(int x, int y){"
            crtCode=&tFunctions; //// codul generat de aici înainte se scrie în secțiunea funcțiilor
            const char *name=consumed->text;// preia numele funcției din tokenul deja consumat
  crtVar=&tFunctions;// variabilele locale ale funcției vor fi scrise tot în zona funcțiilor
  Text_clear(&tFnHeader);// golește bufferul folosit pentru construirea header-ului funcției
  Text_write(&tFnHeader,"%s(",name);// începe construcția antetului funcției: "numeFuncție("
            
            Symbol *s=searchInCurrentDomain(name);
            if(s)tkerr("symbol redefinition: %s",name);
            crtFn=addSymbol(name,KIND_FN);
            crtFn->args=NULL;
            addDomain();
            if(consume(LPAR)){ // deshiderea listei de parametri (
                // funcParams? (opțional)
                if(funcParams()){} //parametrii
                if(consume(RPAR)){ //inchidere listei )
                    if(consume(COLON)){ // astepta : dupa paranteza
                        if(baseType()){  //Verifică tipul de întoarcere (int/real/str)
                            
                            Text_write(&tFunctions,"\n%s %s){\n",cType(ret.type),tFnHeader.buf);
                            // scrie începutul funcției în C:
                            // → tipul de retur (cType(ret.type))
                        // → header-ul complet al funcției (nume și parametri)
                       // rezultatul va arăta ca: "int max(int x, int y){"

                           crtFn->type=ret.type;
                            for(;;){
                                int s2 = iTk; // salveaza pozitia ucrenta 
                                if(defVar()) continue; 
                                iTk = s2; 
                                break;
                            }
                            if(block()){ //blocul de instrucțiuni al funcție
                                if(consume(END)){ // dupa bloc astepta cuvantul end care inchide def fct
                                    Text_write(&tFunctions,"}\n");// închide definiția funcției în codul C (scrie acolada de final)

                                    crtCode=&tMain;// schimbă bufferul curent: de acum codul generat va merge în funcția main()
                                    crtVar=&tBegin;// schimbă bufferul de variabile: de acum variabilele globale vor fi scrise în tBegin
                                    delDomain();
                                    crtFn=NULL;
                                    return true;
                                }else tkerr("lipseste 'end' la finalul functiei");
                            }else tkerr("lipseste blocul de instructiuni al functiei");
                        }else tkerr("lipseste tipul de intoarcere al functiei dupa':'");
                    }else tkerr("lipseste ':' dupa ')'");
                }else tkerr("lipseste ')' dupa parametrii functiei");
            }else tkerr("lipseste '(' dupa numele functiei");
        }else tkerr("lipseste numele functiei dupa 'function'");
    }
    iTk = start;
    return false;
}

//definirea blockului de instr
// block ::= instr+
bool block(){
    int start = iTk; // pozitia curneta in vectorul de tk
    if(!instr()){ //pastreaza prima instrucțiune, regula  instr+, prima e obligatorie.
        iTk = start; // daca nu Exista nicio instr 
        return false;
    }
    // instr+ => repetăm cât timp putem consuma instr
    while(true){
        int s2 = iTk;
        if(!instr()){
            iTk = s2;
            break;
        }
    }
    return true;
}

//definire functie patametru
// funcParams ::= funcParam ( COMMA funcParam )* 
//cel puțin un parametru, urmat de zero sau mai multe secvențe „, parametru`”.
bool funcParams(){
    int start = iTk; //indicele curent din lista de tokeni
    if(!funcParam()){
        iTk = start;
        return false;
    }
    while(consume(COMMA)){ //Dacă am găsit cel puțin un parametru,entru eventuali parametri suplimentari separați prin virgule
       Text_write(&tFnHeader,",");// adaugă o virgulă în lista de parametri ai funcției

        if(!funcParam()) 
        tkerr("lipseste parametru dupa ','");
    }
    return true;
}

// funcParam ::= ID COLON baseType
//pentru un singur parametru de funcție
bool funcParam(){
    int start = iTk;//
    if(consume(ID)){ //numele parametrului
         const char *name=consumed->text;
         Symbol *s=searchInCurrentDomain(name);
         if(s)tkerr("symbol redefinition: %s",name);
         s=addSymbol(name,KIND_ARG);
         Symbol *sFnParam=addFnArg(crtFn,name);
        if(consume(COLON)){
            if(baseType()){
                Text_write(&tFnHeader,"%s %s",cType(ret.type),name);// adaugă în antetul funcției un parametru: "tip nume"
                s->type=ret.type;
            sFnParam->type=ret.type;
                return true;
            }else tkerr("lipseste tipul parametrului dupa ':'");
        }else tkerr("lipseste ':' dupa numele parametrului");
    }
    iTk = start;
    return false;
}

//definire instructiuni
// instr ::= expr? SEMICOLON | IF LPAR expr RPAR block ( ELSE block )? END | RETURN expr SEMICOLON |WHILE LPAR expr RPAR block END
bool instr(){
    int start = iTk; 

    // IF (...)
    if(consume(IF)){ //urmează IF
        if(consume(LPAR)){ //Așteaptă ( după if.
            Text_write(crtCode,"if("); // începe generarea condiției pentru instrucțiunea if în codul C
            if(expr()){ // conditia
                if(ret.type==TYPE_STR)// ret.type este tipul ultimei expresii evaluate sa fie type_str
                tkerr("Conditia if trebuie sa fie de tip int sau real");
                if(consume(RPAR)){ //Așteaptă ) după expresie
                    Text_write(crtCode,"){\n");// închide paranteza condiției și deschide blocul de instrucțiuni al lui if
                    if(block()){ //Așteaptă blocul de instrucțiuni al ramurii if
                        Text_write(crtCode,"}\n");// închide blocul de instrucțiuni (accolada de final) și trece la o linie nouă
                        if(consume(ELSE)){ // else este opțional: dacă apare, îl consumă…
                            Text_write(crtCode,"else{\n");// începe blocul de instrucțiuni pentru ramura else
                            if(!block()) tkerr("lipseste blocul dupa 'else'"); //după else blocul este obligatoriu; altfel eroare.
                       Text_write(crtCode,"}\n");// închide blocul curent de instrucțiuni (accolada de final)
                        }
                        if(consume(END)) return true; // la final tre sa fie end
                        tkerr("lipseste 'end' dupa if/else");
                    }else tkerr("lipseste blocul dupa if(conditie)");
                }else tkerr("lipseste ')' dups conditia lui if");
            }else tkerr("conditie invalida pentru if sau lipseste ')'");
        }else tkerr("lipseste '(' dupa 'if'");
    }
    iTk = start;

    // RETURN expr ;
    if(consume(RETURN)){  //Dacă urmează RETURN, intrăm pe ramura return
        Text_write(crtCode,"return ");//// scrie începutul instrucțiunii return în codul C (urmează expresia)
        if(!expr())//Dacă urmează RETURN, intrăm pe ramura return
         tkerr("lipseste expresia dupa 'return'");
         if(!crtFn)// Verifica daca nu suntem in interiorul unei functii (crtFn == NULL)
         tkerr("return poate fi folosit doar intr-o functie");
             if(ret.type!=crtFn->type)  // Compara tipul expresiei returnate (ret.type) cu tipul functiei (crtFn->type)
             tkerr("tipul returnat trebuie sa fie acelasi cu tipul returnat al functiei");
        if(!consume(SEMICOLON)) 
        tkerr("lipseste ';' dupa return <expr>");
        Text_write(crtCode,";\n"); // scrie un punct și virgulă în codul generat (finalizează instrucția)
       
        return true;
    }
    iTk = start;

    // WHILE (...)
    if(consume(WHILE)){ //ramura while
        Text_write(crtCode,"while("); // începe generarea instrucțiunii while și deschide paranteza condiției
        if(consume(LPAR)){ //aramteza()
            if(expr()){ //expresie 
                if(ret.type==TYPE_STR) // ret.type este tipul ultimei expresii evaluate.
                tkerr("Conditia while trebuie sa fie de tip int sau real");
                if(consume(RPAR)){ //paranteza)
                    Text_write(crtCode,"){\n"); // închide paranteza condiției și deschide blocul de instrucțiuni (accoladă nouă)
                    if(block()){  //bloc de instructiuni
                        if(consume(END)) 
                       { Text_write(crtCode,"}\n"); // închide blocul de instrucțiuni al lui while (accolada finală)
                        return true; //la final end
                       }
                        tkerr("lipseste 'end' dupa while");
                    }else tkerr("lipseste blocul dupa while(conditie)");
                }else tkerr("lipseste ')' dupa conditia lui while");
            }else tkerr("conditie invalida pentru while sau lipseste ')'");
        }else tkerr("lipseste '(' dupa 'while'");
    }
    iTk = start;

    // cazul expr?;
    if(expr()){
        if(!consume(SEMICOLON)) tkerr("lipseste ';' dupa expresie");
        Text_write(crtCode,";\n"); // generează finalul unei instrucțiuni C: punct și virgulă + linie nouă
        return true; 
    }
    iTk = start;

    // doar ';'
    if(consume(SEMICOLON)) return true;

    iTk = start;
    return false;
}

// expr ::= exprLogic
bool expr(){
    return exprLogic();
}

// exprLogic ::= exprAssign ( ( AND | OR ) exprAssign )*
bool exprLogic(){
    if(!exprAssign())
        return false;

    while(true){
        int start = iTk;

        // AND
        if(consume(AND)){
            Ret leftType = ret;
            if(leftType.type == TYPE_STR)
                tkerr("Operandul din stanga al lui && nu poate fi de tip str");

            Text_write(crtCode,"&&"); //// generează operatorul logic AND în codul C

            if(!exprAssign())
                tkerr("lipseste expresia dupa operatorul &&");

            if(ret.type == TYPE_STR)
                tkerr("Operandul din dreapta al lui && nu poate fi de tip str");

            setRet(TYPE_INT, false);
            continue;
        }

        // OR
        if(consume(OR)){
            Ret leftType = ret;
            if(leftType.type == TYPE_STR)
                tkerr("Operandul din stanga al lui || nu poate fi de tip str");

            Text_write(crtCode,"||");// generează operatorul logic or în codul C

            if(!exprAssign())
                tkerr("lipseste expresia dupa operatorul ||");

            if(ret.type == TYPE_STR)
                tkerr("Operandul din dreapta al lui || nu poate fi de tip str");

            setRet(TYPE_INT, false);
            continue;
        }

        // dacă nu mai urmează AND/OR, ieșim din buclă
        iTk = start;
        break;
    }

    return true;
}



bool exprAssign(){
    int start = iTk;//reține poziția curentă în vectorul de tokeni

    if(consume(ID)){
        
        const char *name = consumed->text;
       
        //consumed pointează la tokenul ID citit,
        //name devine textul acelui identificator (de ex. "i")

        if(consume(ASSIGN)){ //consuma egal
             Text_write(crtCode,"%s=",name); // generează partea stângă a unei atribuiri: scrie numele variabilei urmat de '='
            if(!exprComp())
                tkerr("lipseste expresia dupa '='");

            Symbol *s = searchSymbol(name); //caută simbolul cu numele name în tabelul de simboluri
            if(!s)
                tkerr("simbol nedefinit: %s", name);
            if(s->kind == KIND_FN) //verifică dacă simbolul este de tip funcție.
                tkerr("O functie (%s) nu poate fi folosita ca destinatie intr-o atribuire.", name);
            if(s->type != ret.type)/// Compara tipul simbolului (variabila din stanga) cu tipul expresiei din dreapta lui '=' (ret.type setat de exprComp)
                //ret.type conține tipul expresiei din dreapta lui =, setat de exprComp().
                 //s->type este tipul variabilei din stânga. dacă tipurile diferă (ex: int x; x = "abc";), atunci se dă eroare:
              tkerr("Sursa si destinatia unei atribuiri trebuie sa aiba acelasi tip");


            // daca rezultatul unei atribuiri, ca expresie, nu este un l-value (nu poate fi în partea stângă a unei alte atribuiri)
            ret.lval = false;
            return true;
        }
        iTk = start;
    }
    return exprComp(); /// Daca nu a fost recunoscuta forma 'ID = expr', atunci trateaza totul ca o expresie normala si apeleaza exprComp()
}


// exprComp ::= exprAdd ( ( LESS | EQUAL ) exprAdd )?
bool exprComp(){
    if(!exprAdd())
        return false;

    int start = iTk;

    // verificăm dacă urmează < sau ==
    if(consume(LESS)){
        Ret leftType = ret;

        Text_write(crtCode,"<");   // generează operatorul de comparație '<' în codul C

        if(!exprAdd())
            tkerr("lipseste expresia dupa operatorul <");

        if(leftType.type != ret.type)
            tkerr("Diferite tipuri pentru operanzii lui <");

        setRet(TYPE_INT, false);
    }
    else if(consume(EQUAL)){
        Ret leftType = ret;

        Text_write(crtCode,"==");  // generează operatorul de comparație '==' în codul C

        if(!exprAdd())
            tkerr("lipseste expresia dupa operatorul ==");

        if(leftType.type != ret.type)
            tkerr("Diferite tipuri pentru operanzii lui ==");

        setRet(TYPE_INT, false);
    }
    else{
        iTk = start;
    }

    return true;
}



bool exprAdd(){
    if(!exprMul())
        return false;

    while(true){
        int start = iTk; //Salvează poziția curentă în vectorul de tokeni

        if(consume(ADD)){
            Text_write(crtCode,"+");// generează operatorul de comparație '+' în codul C
            Ret leftType = ret; // Salvează tipul rezultatului expresiei din stânga operatorului (+)
            if(leftType.type == TYPE_STR)  // Dacă tipul operandului stâng este string...
                tkerr("Operanzii lui + sau - nu pot fi de tip str");

            if(!exprMul()) 
                tkerr("lipseste expresia dupa operatorul +");

            if(leftType.type != ret.type) /// Compară tipul operandului stâng (leftType.type) cu tipul operandului drept (ret.type)
                tkerr("diferite tipuri pentru operanzii + sau -");

            ret.lval = false;// Rezultatul unei expresii cu + nu este l-value (nu poate sta în stânga la '=')
        }
        else if(consume(SUB)){
            Text_write(crtCode,"-");// generează operatorul de comparație '-' în codul C

            Ret leftType = ret; //Salvează tipul rezultatului expresiei din stânga operatorului (-)
            if(leftType.type == TYPE_STR) // Dacă tipul operandului stâng este string...
                tkerr("Operanzii lui + sau - nu pot fi de tip str");

            if(!exprMul())
                tkerr("lipseste expresia dupa operatorul -");

            if(leftType.type != ret.type) //Compară tipul operandului stâng (leftType.type) cu tipul operandului drept (ret.type)
                tkerr("diferite tipuri pentru operanzii + sau -");

            ret.lval = false;
        }
        else{
            iTk = start;
            break;
        }
    }
    return true;
}


// exprMul ::= exprPrefix ( ( MUL | DIV ) exprPrefix )*
bool exprMul(){
    if(!exprPrefix())
        return false;
        

    while(true){
        int start = iTk;

        if(consume(MUL)){
            Ret leftType = ret; //Salvează tipul rezultatului expresiei din stânga operatorului (-)
            if(leftType.type == TYPE_STR)// Dacă tipul operandului stâng este string...
                tkerr("Operanzii lui * sau / nu pot fi de tip str");

            if(!exprPrefix())
                tkerr("lipseste expresia dupa operatorul *");

            if(leftType.type != ret.type) //Compară tipul operandului stâng (leftType.type) cu tipul operandului drept (ret.type)
                tkerr("diferite tipuri pentru operanzii lui * sau /");

            ret.lval = false; //Rezultatul unei expresii  nu este l-value (nu poate sta în stânga la '=')
        }
        else if(consume(DIV)){
            Text_write(crtCode,"/"); // generează operatorul de comparație '/' în codul C

            Ret leftType = ret;////Salvează tipul rezultatului expresiei din stânga operatorului 
            if(leftType.type == TYPE_STR) // Dacă tipul operandului stâng este string
                tkerr("Operanzii lui * sau / nu pot fi de tip str");

            if(!exprPrefix())
                tkerr("lipseste expresia dupa operatorul /");

            if(leftType.type != ret.type) //Compară tipul operandului stâng (leftType.type) cu tipul operandului drept (ret.type)
                tkerr("diferite tipuri pentru operanzii lui * sau /");

            ret.lval = false;
        }
        else{
            iTk = start;
            break;
        }
    }
    return true;
}



bool exprDiv(){
    if(!exprPrefix()) return false;
    while(true){
        int start = iTk;
        if(consume(DIV)){
            if(!exprPrefix()) tkerr("lipseste expresia dupa operatorul /");
        }else{
            iTk = start;
            break;
        }
    }
    return true;
}

// exprPrefix ::= ( SUB | NOT )? factor
bool exprPrefix(){
    int start = iTk;

    // - factor
    if(consume(SUB)){
        Text_write(crtCode,"-");// generează minus în codul C

        if(!factor())
            tkerr("lipseste expresia dupa '-' unar");

        if(ret.type == TYPE_STR) //Verifică tipul expresiei de după '-' (stocat în ret.type)
            tkerr("expresia lui unary - trebuie s fie de tip int sau real");

        ret.lval = false; // Rezultatul unei expresii cu '-' unar nu este l-value (nu poate apărea în stânga lui '=')
        return true;
    }
    iTk = start;

    // ! factor
    if(consume(NOT)){
        Text_write(crtCode,"!");// generează !' în codul C
        if(!factor())
            tkerr("lipseste expresia dupa '!'");

        if(ret.type == TYPE_STR) ////Verifică tipul expresiei de după '!' (stocat în ret.type)
            tkerr("expresia lui ! trebuie sa fie de tip int sau real");

        setRet(TYPE_INT, false); //(nu poate apărea în stânga lui '=')
        return true;
    }
    iTk = start;

    // doar factor
    return factor();
}


// factor ::= INT|REAL|STR|LPAR expr RPAR | ID ( LPAR ( expr ( COMMA expr )* )? RPAR )?
bool factor(){
    // INT
    if(consume(INT)){
        Text_write(crtCode,"%d",consumed->i);// scrie în cod valoarea unui literal întreg (INT) consumat din tokeni

        setRet(TYPE_INT, false); //Setează tipul expresiei curente la TYPE_INT (adică int)și marchează că NU este l-value (false)
        return true; //S-a recunoscut cu succes un factor de tip întreg, funcția întoarce true
    }
    // REAL
    if(consume(REAL)){
        Text_write(crtCode,"%g",consumed->r);// scrie în cod valoarea unui literal real consumat din tokeni
        setRet(TYPE_REAL, false);//Setează tipul expresiei curente la TYPE_Real(adica r)și marchează că NU este l-value (false)
        return true;
    }
    // STR
    if(consume(STR)){
        Text_write(crtCode,"\"%s\"",consumed->text);// scrie în cod valoarea unui literal str  consumat din tokeni
        setRet(TYPE_STR, false);
        return true;
    }

    int start = iTk; //

    // ( expr )
    if(consume(LPAR)){
        Text_write(crtCode,"(");// generează o paranteză deschisă în codul C (pentru expresii sau apeluri de funcții)
        if(!expr())
            tkerr("expresie invalida intre paranteze sau lipseste ')'");
        if(!consume(RPAR))
            tkerr("lipseste ')' dupa expresie");
        // ret rămâne cel al expresiei
        Text_write(crtCode,")");// generează o paranteză închisă în codul C
        return true;
    }
    iTk = start; //poziția curentă în vectorul de tokeni

    // ID (eventual apel de funcție)
    if(consume(ID)){  // puti()
        
        Symbol *s = searchSymbol(consumed->text); // Caută în tabela de simboluri simbolul cu numele acestui ID
        Text_write(crtCode,"%s",s->name);// scrie numele unui identificator (variabilă sau funcție) în codul generat " x ,y"
        if(!s)
            tkerr("undefined symbol: %s", consumed->text);

        // verificăm dacă urmează apel: (
        if(consume(LPAR)){
            Text_write(crtCode,"(");// generează paranteza deschisă pentru un apel de funcție în codul C
            if(s->kind != KIND_FN) //// Verifică dacă simbolul 's' NU este de tip funcție (KIND_FN).
                tkerr("%s nu poate fi apelata, deoarece nu este o functie", s->name);

            Symbol *argDef = s->args;  //Creează un pointer 'argDef' la lista de argumente  (parametri) definiți pentru funcția 's' (ex: pentru max(x:int, y:int),
                                       //s->args este lista (x, y))
            // ( expr ( , expr )* )?
            if(expr()){   // Daca exista o expresie ca PRIM argument in apelul de functie (ex: max(i,5,...))
                                  // In momentul asta, 'ret.type' contine tipul PRIMULUI argument evaluat
                if(!argDef)   //daca ca NU mai avem parametri definiti in functie,// dar totusi am primit un argument in apel
                    tkerr("Functia %s este apelata cu prea multe argumente", s->name);
                                                              
                if(argDef->type != ret.type) // Comparam tipul parametrului curent (argDef->type)// cu tipul expresiei (ret.type) evaluata ca argument
                     tkerr("Tipul argumentului la apelul functiei %s este diferit de cel dat la definitia sa", s->name);
                                                              
                argDef = argDef->next;   // Trecem la urmatorul parametru definit in lista de argumente a functiei 

                while(consume(COMMA)){  // Cat timp gasim o virgula ',' in lista de argumente (ex: max(i, 5, 10, ...))
                    Text_write(crtCode,",");// scrie o virgulă în lista de argumente a apelului de funcție
                    if(!expr())      // Dupa fiecare virgula trebuie sa urmeze O EXPRESIE (urmatorul argument)
                        tkerr("lipseste expresia dupa ',' in lista de argumente");

                    if(!argDef)   // Daca NU mai avem parametri in definitie (argDef == NULL), dar continuam sa gasim argumente in apel
                        tkerr("Functia %s este apelata cu prea multe argumente", s->name);

                    if(argDef->type != ret.type)  // Verificam din nou tipul parametrului curent (argDef->type)
                                                   // comparat cu tipul expresiei din argumentul tocmai evaluat (ret.type)
                        tkerr("Tipul argumentului la apelul functiei %s este diferit de cel dat la definitia sa", s->name);
                                                              // Daca difera, raportam eroare de incompatibilitate de tip

                    argDef = argDef->next;                    // Avansam la urmatorul parametru din definitia functiei
                                                              // pentru urmatorul argument din lista (daca exista)
                }                                             
            }                                           


            if(!consume(RPAR))
                tkerr("lipseste ')' la apelul de functie");
                Text_write(crtCode,")");// generează paranteza închisă a unui apel de funcție


            if(argDef)
                tkerr("Functia %s este apelata cu prea putine argumente", s->name);

            setRet(s->type, false);   // rezultatul apelului nu e l-value
            return true;
        }else{
            // doar variabilă / constantă
            if(s->kind == KIND_FN)
                tkerr("Functia %s poate fi apelata doar", s->name);

            setRet(s->type, true);    // este l-value
            return true;
        }
    }

    return false;
}


// punctul de intrare 
void parse(){
    iTk = 0;
    program();
}
