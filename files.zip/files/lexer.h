#pragma once

	enum{
    //identificatori
    ID,
    // civinte cheie
    VAR,FUNCTION,IF,ELSE,WHILE,END,RETURN,TYPE_INT,TYPE_REAL,TYPE_STR,
    // literali
    INT,REAL,STR
    // delimitatori
    ,COMMA,COLON,SEMICOLON,LPAR,RPAR,FINISH
    // operatori
    ,ADD,SUB,MUL,DIV,AND,OR,NOT,ASSIGN,EQUAL,NOTEQ,LESS,GREATER,GREATEREQ
};

#define MAX_STR		127

//structura unui token
typedef struct{
	int code;		// ID, TYPE_INT, ...
	int line;		// the line from the input file
	union{
		char text[MAX_STR+1];		// the chars for ID, STR
		int i;		// the value for INT
		double r;		// the value for REAL
		};
	}Token;

#define MAX_TOKENS		4096
//Bufferul global de tokeni și numărul lor
extern Token tokens[];
extern int nTokens;

void tokenize(const char *pch);

void showTokens();

//mesaje de eroare
//constante 
//real 
//9.    err lispa cifra dupa punct 
//operatori
//and  err lispa al doilea umpersant
//or
//constante 
//str  4 mesaje de eroare

// lexer.c

 


