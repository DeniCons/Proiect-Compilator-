#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ad.h"
#include "utils.h"

Ret ret; // retine tipul valorii returnate
Domain *symTable; // // demniul curent 
Symbol *crtFn; // // retine functia curenta

Domain *addDomain(){
	puts("creates a new domain");
	Domain *d=(Domain*)safeAlloc(sizeof(Domain)); // alocam memorie pt un domniu nou
	d->parent=symTable;// domeniul curent devine parinte
	d->symbols=NULL;//la inceput nu sunt simboluri
	symTable=d;// domniul creat devine domeniul activ
	return d;
	}

void delSymbols(Symbol *list);

//sterge un singur simbol 
// daca simbolul e fct , are o lista de arg care tre stearsa
void delSymbol(Symbol *s){
	printf("\tdeletes the symbol %s\n",s->name);
	if(s->kind==KIND_FN){ //// Verifică dacă simbolul este de tip funcție
		delSymbols(s->args); // Dacă este funcție, atunci șterge și lista de argumente asociată funcției
		}
	free(s); //// Eliberează memoria alocată pentru acest simbol
	}

	// sterge o lista intreaga de simboluri 
void delSymbols(Symbol *list){
	for(Symbol *s1=list,*s2;s1;s1=s2){ //parcurge lista
		s2=s1->next; //tine impte urm nod 
		delSymbol(s1);//sterge simbolul curent
		}
	}

void delDomain(){
	puts("deletes the current domain");
	Domain *parent=symTable->parent; // salvam domeniul parinte
	delSymbols(symTable->symbols); // stergem toate simbolurile din dom curent 
	free(symTable);
	symTable=parent; // ne intoarcem la domeniul parinte 
	puts("returns to the parent domain");
	}

	//cautam un simbol intr -o lista
Symbol *searchInList(Symbol *list,const char *name){
	for(Symbol *s=list;s;s=s->next){ // Parcurge lista simplu înlănțuită
		if(!strcmp(s->name,name))// Compară numele simbolului curent (s->name) cu 'name'
		//// Dacă numele corespund, întoarce adresa simbolului găsit
		return s;
		}
	return NULL;
	}

	//cauta un simbol doar in domeniul curent
Symbol *searchInCurrentDomain(const char *name){
	return searchInList(symTable->symbols,name);
	}


	// cauta un simbol in toate domeniile 
	//prima data local, dupa in dom parinte si global
Symbol *searchSymbol(const char *name){
	for(Domain *d=symTable;d;d=d->parent){
		// Caută simbolul în lista de simboluri a domeniului curent
		Symbol *s=searchInList(d->symbols,name);
		if(s)return s;//// Dacă l-a găsit, îl returnează 
		}
	return NULL;
	}


Symbol *createSymbol(const char *name,int kind){
	// // Alocă dinamic memorie pentru un nou obiect de tip Symbol
	Symbol *s=(Symbol*)safeAlloc(sizeof(Symbol));
	s->name=name;// Atribuie câmpului 'name' al simbolului adresa string-ului primit ca parametru
	s->kind=kind;// Setează felul  simbolului (kind), de exemplu poate fi variabilă, funcție etc. (king arg)
	return s;// Returnează pointerul la simbolul nou creat
	}

 //adauga simbolul in domeniul curent 	
Symbol *addSymbol(const char *name,int kind){
	printf("\tadds symbol %s\n",name);
	Symbol *s=createSymbol(name,kind);//adr simb nou creat e stocata in pointerul s
	// in insereaza la incepultul listei 
	//symTable - dom curent
	// symTable->symbols - capul listei de simb din dom curent 
	s->next=symTable->symbols;// s se pun ein fata celorlalnet simb 
	symTable->symbols=s;// actualizam capul listei
	return s;
	}
// ex: s1-> s2-> s3 => s->s1->s2->s3



Symbol *addFnArg(Symbol *fn,const char *argName){
	printf("\tadds symbol %s as argument\n",argName);
	Symbol *s=createSymbol(argName,KIND_ARG);// creaza nou simbol pt argument 
	s->next=NULL;
	if(fn->args){ // fn->args e capul listei de arg 
		// adauga la final 
		Symbol *p; 
		for(p=fn->args;p->next;p=p->next){}
		p->next=s; // trece la urm arg 
		// cand bulca se permina p e ultimul nod din lista de arg 
		}else{ // daca fn->arg e null --=> fct nu are inca niciun argument
		fn->args=s; //primul argument
		}
	return s;
	}

