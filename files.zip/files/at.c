#include <stddef.h>                    

#include "lexer.h"                      
#include "ad.h"                

// adds in ST a function with an argument
// the argument has the type argType and the function returns the type retType
Symbol *addFn1Arg(const char *fnName,int argType,int retType){
    Symbol *fn=addSymbol(fnName,KIND_FN);   // Adaugă în tabela de simboluri un nou simbol de tip funcție cu numele fnName
    fn->type=retType;                       // Setează tipul de întoarcere al funcției (retType)
    fn->args=NULL;                          // Inițializează lista de argumente a funcției cu NULL (deocamdată fără argumente)
    Symbol *arg=addFnArg(fn,"arg");         // Adaugă un argument formal cu numele "arg" la funcția fn
    arg->type=argType;                      // Setează tipul argumentului la argType (int, real sau str)
    return fn;                              // Returnează simbolul funcției create
    }

void addPredefinedFns(){
    addFn1Arg("puti",TYPE_INT,TYPE_INT);    // Adaugă funcția predefinită puti(int):int în tabela de simboluri
    addFn1Arg("putr",TYPE_REAL,TYPE_REAL);  // Adaugă funcția predefinită putr(real):real
    addFn1Arg("puts",TYPE_STR,TYPE_STR);    // Adaugă funcția predefinită puts(str):str
    }

void setRet(int type,bool lval){
    ret.type=type;                          // Setează tipul expresiei curente (folosit în analizatorul de tipuri)
    ret.lval=lval;                          // Setează dacă expresia curentă este l-value (true) sau nu (false)
    }
