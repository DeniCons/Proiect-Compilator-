#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include<stdlib.h>

#include "lexer.h"
#include "utils.h"

Token tokens[MAX_TOKENS];
int nTokens;

int line=1;		// the current line in the input file -// linia curentă

// adds a token to the end of the tokens list and returns it
// sets its code and line
//adaugă un token la final
Token *addTk(int code){
	if(nTokens==MAX_TOKENS)err("too many tokens");
	Token *tk=&tokens[nTokens];  //adresa elementului următor liber din vectorul
	tk->code=code; // selecteaza tipul token ului
	tk->line=line; //linia din sursă pe care a fost găsit tokenul
	nTokens++;  // cretem numarul de token  
	return tk;
	}

// copy in the dst buffer the string between [begin,end)
//dst bufferul unde se copiaza , begin adresa primului char 
char *copyn(char *dst,const char *begin,const char *end){  
	char *p=dst;   //pointer  care pornește la începutul lui dst
	if(end-begin>MAX_STR)err("string too long"); // verifica lungimea ceruta
	while(begin!=end)*p++=*begin++; //Copiază, caracter cu caracter, până când begin ajunge la end
	*p='\0';
	return dst;
	}

void tokenize(const char *pch){
	const char *start;     //start marchează începuturi de lexeme.            
	Token *tk;                      //   pch plimbă un cursor prin text.
	char buf[MAX_STR+1];     //buf temporar pentru text.
	for(;;){
		switch(*pch){
			case ' ':case '\t':pch++;break;  // function si trece pestre spatiu la urm cuvant  
			case '\r':		// handles different kinds of newlines (Windows: \r\n, Linux: \n, MacOS, OS X: \r or \n)
				if(pch[1]=='\n')pch++;
				// fallthrough to \n
			case '\n':
				line++;
				pch++;
				break;
			case '\0':addTk(FINISH);return;
			case ',':addTk(COMMA);pch++;break;
			case '=':
				if(pch[1]=='='){ //a==b sau int e=0
					addTk(EQUAL);
					pch+=2;
					}else{
					addTk(ASSIGN);
					pch++;
					}
				break;
			case ':': addTk(COLON); pch++; break;
            case ';': addTk(SEMICOLON); pch++; break;
            case '(': addTk(LPAR); pch++; break;
            case ')': addTk(RPAR); pch++; break;

            //  operatori simpli 
            case '+': addTk(ADD); pch++; break;
            case '-': addTk(SUB); pch++; break;
            case '*': addTk(MUL); pch++; break;

            // AND/OR (&&, ||) 
            case '&':
                if(pch[1]=='&'){ addTk(AND); pch+=2; }
                else err("LIpsa al doile & de la ANd: %c (%d)",*pch,*pch);
                break;
            case '|':
                if(pch[1]=='|'){ addTk(OR); pch+=2; }
                else err("Lipsa al doilea | de la OR: %c (%d)",*pch,*pch);
                break;

            //  comentarii si DIV 
            case '/':
                if(pch[1]=='/'){                 // COMMENT: '//' [^\n\r\0]*
                    pch+=2;
                    while(*pch && *pch!='\n' && *pch!='\r') pch++;
                    break;     // nu produce token   // consumat, fara token
                }else{
                    addTk(DIV); //impartire
                    pch++;
                    break;
                }

            //  !, !=
            case '!':  
                if(pch[1]=='='){ addTk(NOTEQ); pch+=2; } //daca e urmat de egal
                else { addTk(NOT); pch++; }
                break;

            // <, >, >= 
            case '<':
                addTk(LESS); pch++; break;
            case '>':
                if(pch[1]=='='){ addTk(GREATEREQ); pch+=2; }
                else { addTk(GREATER); pch++; }
                break;

			case '"': {
				pch++; // sar peste char " de inceput
				start = pch;  //începutul conținutului șirului
				while (*pch != '"' && *pch != '\0' && *pch != '\n')  //Parcurg caracterele până găsesc ghilimeaua de inchidere
				pch++;
				if (*pch != '"') err("%d șir neterminat",line); // daca s a orpit fara sa gaseasca a 2 a ghilimea
				char *text = copyn(buf, start, pch);  //toate caracterele dintre ghilimele fara ghilimea de închidere
				tk = addTk(STR);  //un token nou de tip STR și îl adaugi în vector
				strcpy(tk->text, text); //Stochezi conținutul șirului (fără ghilimele)
				pch++; // consumă ghilimelele
				break;
        	}
			default:
				// ID sau cuvinte cheie isalpha se trransforma din char in cifra
				if(isalpha((unsigned char)*pch)||*pch=='_'){
					for(start=pch++;isalnum((unsigned char)*pch)||*pch=='_';pch++){}
					char *text=copyn(buf,start,pch);
					if(strcmp(text,"var")==0) addTk(VAR);
                    else if(strcmp(text,"function")==0) addTk(FUNCTION);
                    else if(strcmp(text,"if")==0) addTk(IF);
                    else if(strcmp(text,"else")==0) addTk(ELSE);
                    else if(strcmp(text,"while")==0) addTk(WHILE);
                    else if(strcmp(text,"end")==0) addTk(END);
                    else if(strcmp(text,"return")==0) addTk(RETURN);
                    else if(strcmp(text,"int")==0) addTk(TYPE_INT);
                    else if(strcmp(text,"real")==0) addTk(TYPE_REAL);
                    else if(strcmp(text,"str")==0) addTk(TYPE_STR);
                    else{
                        tk=addTk(ID);
                        strcpy(tk->text,text); // numele identificatorului
                    }
				}
				// INT si REAL
				else if(isdigit((unsigned char)*pch)){// verfica sa fie numar
					const char *q = pch; // porneste de unde a ramas pch 
					while(isdigit((unsigned char)*q)) // ne ducem este toate cifrele -partea inteaga 
					 q++;
					int isReal = 0; 
					if(*q=='.'){  // verifac, daca nr e real 
						const char *q2 = q+1; // incepe dupa punct 
						if(isdigit((unsigned char)*q2)){    // REAL ::= [0-9]+ '.' [0-9]+
							isReal = 1;
							while(isdigit((unsigned char)*q2)) q2++; // avansam peste toate cifrele de dupa punct 
							q = q2; // mutat q la finalul nr real 
						}
						else
						err("Eroare numar real %c (%d)",*pch,*pch);
					}
					if(isReal){ // adaugam tocken daca e real sau nu 
						char *text = copyn(buf,pch,q);
						tk = addTk(REAL);
						tk->r = strtod(text,NULL); //Convertim textul numeric în double
						pch = q;
					}else{
						char *text = copyn(buf,pch,q);
						tk = addTk(INT);
						tk->i = (int)strtol(text,NULL,10);
						pch = q;
						
					}
				}
				// STR ::= " [^"]* " // sa verifi si    verificare \0
				/*else if(*pch=='"'){ // daca avem gilimea avem recunoasterea unui sir 
					pch++;                 // sarim peste " de inceput
					start = pch;
					while(*pch && *pch!='"'){ // parcurgem pana la urmatoare ghilimea de inchidere
						if(*pch=='\n' || *pch=='\r' )
						err("string literal not terminated");
						pch++;
					}  
					if(*pch!='"') err("Siurul nu e"); //Dacă nu suntem pe " la final de sir e eroare
					char *text = copyn(buf,start,pch);// copiem continutul fara ghilimele 
					tk = addTk(STR);
					strcpy(tk->text,text);//Stocam textul în payload-ul text al tokenului.
					pch++;                 // sarim peste ghilimea de inchidere
				}*/
				else err("invalid char: %c (%d)",*pch,*pch);
			}
		}
	}


/*void showTokens(){
	for(int i=0;i<nTokens;i++){
		Token *tk=&tokens[i];
		printf("%d ",tk->line);
		}
		 
	}
*/void showTokens(){
    for(int i=0;i<nTokens;i++){
        Token *tk=&tokens[i];
        printf("%d ", tk->line);
        switch(tk->code){
            case ID:         printf("ID:%s", tk->text); break;
            case VAR:        printf("VAR"); break;
            case FUNCTION:   printf("FUNCTION"); break;
            case IF:         printf("IF"); break;
            case ELSE:       printf("ELSE"); break;
            case WHILE:      printf("WHILE"); break;
            case END:        printf("END"); break;
            case RETURN:     printf("RETURN"); break;
            case TYPE_INT:   printf("TYPE_INT"); break;
            case TYPE_REAL:  printf("TYPE_REAL"); break;
            case TYPE_STR:   printf("TYPE_STR"); break;

            case INT:        printf("INT:%d", tk->i); break;
            case REAL:       printf("REAL:%g", tk->r); break;
            case STR:        printf("STR:%s", tk->text); break;

            case COMMA:      printf("COMMA"); break;
            case COLON:      printf("COLON"); break;
            case SEMICOLON:  printf("SEMICOLON"); break;
            case LPAR:       printf("LPAR"); break;
            case RPAR:       printf("RPAR"); break;
            case FINISH:     printf("FINISH"); break;

            case ADD:        printf("ADD"); break;
            case SUB:        printf("SUB"); break;
            case MUL:        printf("MUL"); break;
            case DIV:        printf("DIV"); break;
            case AND:        printf("AND"); break;       // &&
            case OR:         printf("OR"); break;        // ||
            case NOT:        printf("NOT"); break;       // !
            case ASSIGN:     printf("ASSIGN"); break;    // =
            case EQUAL:      printf("EQUAL"); break;     // ==
            case NOTEQ:      printf("NOTEQ"); break;     // !=
            case LESS:       printf("LESS"); break;      // <
            case GREATER:    printf("GREATER"); break;   // >
            case GREATEREQ:  printf("GREATEREQ"); break; // >=

            default:         printf("UNKNOWN(%d)", tk->code); break;
        }
        printf("\n");
    }
}
