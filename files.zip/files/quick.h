// Acest antet nu face parte din compilator, deci nu va fi adăugat la proiect!

// Acest antet implementează biblioteca funcțiilor predefinite în Quick
// și este inclus în codul generat (din 1.c)

#include <stdio.h>


// definește tipul de date pentru TYPE_STR
typedef char *str;

// static - atunci când este utilizat pentru o funcție, o face privată și locală într-un fișier de cod
// astfel încât definiția poate fi duplicată în mai multe fișiere de cod.
// În acest fel, „quick.h” poate fi inclus în mai multe fișiere de cod
// fără erori de redefinire a simbolurilor (ex: pentru „puti”).
static void puti(int val){
	printf("%d\n",val);
	}

static void putr(double val){
	printf("%g\n",val);
	}


// „puts” este deja declarat în stdio.h

