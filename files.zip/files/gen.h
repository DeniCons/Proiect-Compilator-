#pragma once

#include <stddef.h>


// O implementare simplă a unui buffer dinamic în care sunt scrise caractere.
// Pe măsură ce sunt scrise caractere, bufferul va crește.
typedef struct{
	char *buf;		// buffer
	size_t n;		// nr de caractere din buf
	}Text;


// La fel ca printf, dar caracterele sunt scrise în buffer-ul "text", nu pe ecran.
void Text_write(Text *text,const char *fmt,...);

// Șterge caracterele dintr-un buffer
void Text_clear(Text *text);

extern Text tBegin	
// pentru fișierul antet și variabilele globale
	,tMain		// codul global Quick, care va fi considerat corpul funcției principale C
	,tFunctions	// funcțiile din Quick
	,tFnHeader	// utilizat temporar la generarea antetului funcției
	;


// acești pointeri vor indica către buffere diferite
// în funcție de domeniul curent (într-o funcție sau global)
extern Text *crtCode;		// dacă este într-o funcție, indică către tFunctions, altfel către tMain
extern Text *crtVar;		// dacă este într-o funcție, indică către tFunctions, altfel către tBegin

// returnează numele în C pentru un tip Quick (ex: TYPE_REAL -> double)
// type = TYPE_*
const char *cType(int type);
