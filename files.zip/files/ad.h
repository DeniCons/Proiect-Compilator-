#pragma once

#include <stdbool.h>

typedef struct{
	int type;		// TYPE_*
	bool lval;	// dacă este o valoare-stânga (necesar pentru analiza tipurilor)”
	}Ret;

extern Ret ret;	// folosit pentru a stoca datele returnate de anumite reguli sintactice
enum{KIND_VAR,KIND_ARG,KIND_FN};

struct Symbol;typedef struct Symbol Symbol;
struct Symbol{
	const char *name;		// referință la un nume stocat într-un token
	int kind;		// KIND_*
	int type;	// TYPE_* from tokens
	union{
		Symbol *args;	// pentru funcții: lista cu argumentele funcției
		bool local;		// pentru variabile: dacă este locală
		};
	Symbol *next;		// legătura către următorul Symbol din listă
	};
struct Domain;typedef struct Domain Domain;
struct Domain{
	Domain *parent;		// părintele acestui domeniu sau NULL pentru domeniul global
	Symbol *symbols;		// listă simplu înlănțuită de simboluri
	};

extern Domain *symTable;	// tabela de simboluri (implementată ca o stivă de domenii)

//pointer la simbolul funcției curente, dacă este analizată o funcție,
//sau NULL în afara funcțiilor
extern Symbol *crtFn;

Domain *addDomain();		// adaugă un nou domeniu în ST ca domeniu curent
void delDomain();	// șterge domeniul curent din ST și îl returnează pe ultimul
Symbol *searchInCurrentDomain(const char *name);		// caută un simbol după nume doar în domeniul curent
Symbol *searchSymbol(const char *name);		// caută în toate domeniile
Symbol *addSymbol(const char *name,int kind);	// adaugă un simbol în domeniul curent
Symbol *addFnArg(Symbol *fn,const char *argName);	// adaugă un argument la simbolul funcției


